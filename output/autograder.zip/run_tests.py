#!/usr/bin/env python3

import unittest
import sys
from pathlib import Path
from gradescope_utils.autograder_utils.json_test_runner import JSONTestRunner

def main():
    """Main test runner that combines all question tests."""
    # Create test suite
    loader = unittest.TestLoader()
    suite = unittest.TestSuite()
    
    suite = unittest.defaultTestLoader.discover('tests') 
    # Run tests with Gradescope utilities
    with open('/autograder/results/results.json', 'w') as f:
        runner = JSONTestRunner(visibility='hidden', stream=f)
        runner.run(suite)

if __name__ == '__main__':
    main()